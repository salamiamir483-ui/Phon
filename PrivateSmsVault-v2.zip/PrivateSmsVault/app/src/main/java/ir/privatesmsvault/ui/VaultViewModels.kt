package ir.privatesmsvault.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.privatesmsvault.data.PrivateEvent
import ir.privatesmsvault.data.PrivateNumber
import ir.privatesmsvault.data.VaultDatabase
import ir.privatesmsvault.data.VaultRepository
import ir.privatesmsvault.vault.PinVault
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class VaultViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = VaultRepository(VaultDatabase.get(app).vaultDao())
    private val query = MutableStateFlow("")
    val searchQuery: StateFlow<String> = query.asStateFlow()
    val numbers: StateFlow<List<PrivateNumber>> = query.flatMapLatest(repo::numbers)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val events: StateFlow<List<PrivateEvent>> = repo.events()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val unreadCount: StateFlow<Int> = repo.unreadCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun search(value: String) { query.value = value }
    fun saveNumber(phone: String, label: String, id: Long = 0, done: () -> Unit = {}) = viewModelScope.launch {
        try { repo.saveNumber(phone, label, id); _message.value = "شماره ذخیره شد"; done() }
        catch (e: Exception) { _message.value = e.message ?: "ذخیره انجام نشد" }
    }
    fun deleteNumber(item: PrivateNumber) = viewModelScope.launch { repo.deleteNumber(item.id); _message.value = "شماره حذف شد" }
    fun addEvent(item: PrivateEvent, done: () -> Unit = {}) = viewModelScope.launch { repo.addEvent(item); _message.value = "رویداد ثبت شد"; done() }
    fun markRead(event: PrivateEvent) = viewModelScope.launch { repo.markEventRead(event.id) }
    fun markThreadRead(phone: String) = viewModelScope.launch { repo.markThreadRead(phone) }
    fun clearMessage() { _message.value = null }
}

class PinViewModel(app: Application) : AndroidViewModel(app) {
    private val vault = PinVault(app)
    private val _enabled = MutableStateFlow(vault.isEnabled())
    val enabled: StateFlow<Boolean> = _enabled.asStateFlow()
    private val _hasPin = MutableStateFlow(vault.hasPin())
    val hasPin: StateFlow<Boolean> = _hasPin.asStateFlow()
    private val _unlocked = MutableStateFlow(!vault.isEnabled())
    val unlocked: StateFlow<Boolean> = _unlocked.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun unlock(pin: String): Boolean {
        val success = vault.verify(pin)
        _unlocked.value = success
        _error.value = if (success) null else "PIN نادرست است"
        return success
    }
    fun savePin(pin: String, oldPin: String? = null): Boolean {
        if (pin.length != 6 || pin.any { !it.isDigit() }) { _error.value = "PIN باید دقیقاً ۶ رقم باشد"; return false }
        if (_hasPin.value && oldPin != null && !vault.verify(oldPin)) { _error.value = "PIN فعلی درست نیست"; return false }
        return try {
            vault.setPin(pin); vault.setEnabled(true); _enabled.value = true; _hasPin.value = true
            _unlocked.value = true; _error.value = null; true
        } catch (e: Exception) { _error.value = e.message ?: "ذخیره PIN ممکن نشد"; false }
    }
    fun setEnabled(value: Boolean) {
        if (value && !_hasPin.value) { _error.value = "ابتدا یک PIN تنظیم کنید"; return }
        vault.setEnabled(value); _enabled.value = value; _unlocked.value = !value
    }
    fun setErrorForUi(value: String) { _error.value = value }
    fun clearError() { _error.value = null }
}
