package ir.privatesmsvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import ir.privatesmsvault.data.PrivateEvent
import ir.privatesmsvault.data.PrivateNumber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.net.URLEncoder
import java.net.URLDecoder

private val pageBg = Color(0xFFFAF8FC)
private val lilac = Color(0xFF8068B5)

@Composable
fun VaultApp() {
    val vm: VaultViewModel = viewModel()
    val pin: PinViewModel = viewModel()
    val enabled by pin.enabled.collectAsState()
    val unlocked by pin.unlocked.collectAsState()
    val nav = rememberNavController()
    if (enabled && !unlocked) {
        PinScreen(pin, setup = false) { value, _ -> pin.unlock(value) }
        return
    }
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(vm, { nav.navigate("numbers") }, { nav.navigate("settings") }, { nav.navigate("events") }, { nav.navigate("pin") }) }
        composable("events") { EventsScreen(vm, { nav.popBackStack() }, { phone -> nav.navigate("chat/${enc(phone)}") }, { nav.navigate("event/new") }) }
        composable("event/new") { NewEventScreen(vm, { nav.popBackStack() }) }
        composable("numbers") { NumbersScreen(vm, { nav.popBackStack() }, { nav.navigate("add/0") }, { item -> nav.navigate("add/${item.id}") }, { phone -> nav.navigate("chat/${enc(phone)}") }) }
        composable("add/{id}", arguments=listOf(navArgument("id"){type=NavType.LongType})) { entry ->
            val id = entry.arguments?.getLong("id") ?: 0L
            val numbers by vm.numbers.collectAsState()
            EditNumberScreen(id, numbers.firstOrNull { it.id == id }, { nav.popBackStack() }) { phone,label -> vm.saveNumber(phone,label,id) { nav.popBackStack() } }
        }
        composable("chat/{phone}", arguments=listOf(navArgument("phone"){type=NavType.StringType})) { entry ->
            val phone = dec(entry.arguments?.getString("phone") ?: "")
            ChatScreen(phone, vm, { nav.popBackStack() })
        }
        composable("settings") { SettingsScreen(pin, { nav.popBackStack() }, { nav.navigate("numbers") }, { nav.navigate("pin") }, { nav.navigate("events") }) }
        composable("pin") { PinScreen(pin, setup = true, onSubmit = { pinValue, oldPin -> if (pin.savePin(pinValue, oldPin)) nav.popBackStack() }) }
    }
}

private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
private fun dec(s:String)=URLDecoder.decode(s,"UTF-8")

@Composable private fun Screen(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(pageBg).statusBarsPadding().navigationBarsPadding(), content=content)
}
@Composable private fun Header(title:String, back:(()->Unit)?=null, action:@Composable (() -> Unit)?=null) {
    Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically) {
        if(back!=null) IconButton(onClick=back){Icon(Icons.Default.ArrowForward,"بازگشت")}
        Text(title,Modifier.weight(1f),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        action?.invoke()
    }
}
@Composable private fun HomeScreen(vm:VaultViewModel, numbers:()->Unit, settings:()->Unit, events:()->Unit, pin:()->Unit) {
    val list by vm.events.collectAsState(); val unread by vm.unreadCount.collectAsState()
    Screen {
        Header("حریم پیامک", action={ IconButton(onClick=settings){Icon(Icons.Default.Settings,"تنظیمات")} })
        Text("فضای خصوصی شما",Modifier.padding(start=20.dp,top=8.dp,bottom=10.dp),color=lilac,fontWeight=FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            SummaryCard("رویدادها",list.size.toString(),Icons.Default.Forum,Modifier.weight(1f),events)
            SummaryCard("خوانده‌نشده",unread.toString(),Icons.Default.MarkEmailUnread,Modifier.weight(1f),events)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=12.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            FilledButton("شماره‌های خصوصی",Icons.Default.Lock,Modifier.weight(1f),numbers)
            OutlinedButton(onClick=pin,modifier=Modifier.weight(1f),shape=RoundedCornerShape(18.dp)){Icon(Icons.Default.Password,null);Spacer(Modifier.width(6.dp));Text("قفل PIN")}
        }
        Text("آخرین رویدادها",Modifier.padding(start=20.dp,top=6.dp,bottom=8.dp),fontWeight=FontWeight.Bold)
        if(list.isEmpty()) EmptyCard("هنوز رویدادی ثبت نشده است","رویدادها به‌صورت دستی/محلی ثبت می‌شوند؛ رهگیری سیستمی فعال نیست.")
        LazyColumn(contentPadding=PaddingValues(horizontal=14.dp,vertical=4.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(list.take(30),key={it.id}) { EventRow(it) { events() } }
        }
    }
}
@Composable private fun SummaryCard(title:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier,onClick:()->Unit) {
    Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) { Icon(icon,null,tint=lilac); Text(value,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text(title,color=MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
@Composable private fun FilledButton(text:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier,onClick:()->Unit) {
    Button(onClick=onClick,modifier=modifier.heightIn(min=52.dp),shape=RoundedCornerShape(18.dp)) { Icon(icon,null);Spacer(Modifier.width(6.dp));Text(text) }
}
@Composable private fun EmptyCard(title:String,detail:String) {
    Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=8.dp),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(20.dp)){Text(title,fontWeight=FontWeight.SemiBold);Text(detail,Modifier.padding(top=6.dp),color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.bodySmall)}
    }
}

@Composable private fun EventsScreen(vm:VaultViewModel,back:()->Unit,open:(String)->Unit,add:()->Unit) {
    val events by vm.events.collectAsState(); var query by remember{mutableStateOf("")}
    Screen { Header("رویدادها",back,action={IconButton(onClick=add){Icon(Icons.Default.Add,"ثبت رویداد")}})
        OutlinedTextField(query,{query=it},Modifier.fillMaxWidth().padding(horizontal=16.dp),label={Text("جستجوی شماره یا متن")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(18.dp))
        val filtered=events.filter { it.phoneNumber.contains(query,true)||it.body.contains(query,true) }
        if(filtered.isEmpty()) EmptyCard("رویدادی پیدا نشد","رویدادهای تماس/پیامک محلی اینجا نمایش داده می‌شوند.")
        LazyColumn(contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) { items(filtered,key={it.id}){e->EventRow(e){open(e.phoneNumber)} } }
    }
}
@Composable private fun EventRow(e:PrivateEvent,onClick:()->Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(Color(0xFFECE5F7),CircleShape),contentAlignment=Alignment.Center){Icon(if(e.eventType=="CALL") Icons.Default.Call else Icons.Default.Sms,null,tint=lilac)}
            Column(Modifier.weight(1f).padding(horizontal=12.dp)) {
                Text(e.phoneNumber,fontWeight=FontWeight.SemiBold)
                Text((if(e.eventType=="CALL")"تماس" else "پیامک")+" • "+(if(e.direction=="OUT")"خروجی" else "ورودی"),color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.bodySmall)
                if(e.body.isNotBlank()) Text(e.body,maxLines=1,color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment=Alignment.End){Text(formatDate(e.occurredAt),style=MaterialTheme.typography.labelSmall);Text(if(e.isRead)"خوانده‌شده" else "خوانده‌نشده",color=if(e.isRead)Color.Gray else lilac,style=MaterialTheme.typography.labelSmall)}
        }
    }
}
private fun formatDate(time:Long):String = SimpleDateFormat("yyyy/MM/dd  HH:mm",Locale("fa","IR")).format(Date(time))

@Composable private fun NumbersScreen(vm:VaultViewModel,back:()->Unit,add:()->Unit,edit:(PrivateNumber)->Unit,open:(String)->Unit) {
    val list by vm.numbers.collectAsState(); val query by vm.searchQuery.collectAsState()
    Screen { Header("شماره‌های خصوصی",back,action={IconButton(onClick=add){Icon(Icons.Default.Add,"افزودن شماره")}})
        OutlinedTextField(query,{vm.search(it)},Modifier.fillMaxWidth().padding(horizontal=16.dp),label={Text("جستجوی شماره یا نام")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(18.dp))
        if(list.isEmpty()) EmptyCard("شماره‌ای ندارید","با دکمهٔ + یک شمارهٔ خصوصی اضافه کنید.")
        LazyColumn(contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){items(list,key={it.id}){item->
            Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f).clickable{open(item.phoneNumber)}){Text(item.label.ifBlank{"بدون نام"},fontWeight=FontWeight.SemiBold);Text(item.phoneNumber,color=MaterialTheme.colorScheme.onSurfaceVariant)}
                    IconButton(onClick={edit(item)}){Icon(Icons.Default.Edit,"ویرایش",tint=lilac)}
                    IconButton(onClick={vm.deleteNumber(item)}){Icon(Icons.Default.Delete,"حذف",tint=Color(0xFFB64C64))}
                }
            }
        }}
        Button(onClick=add,modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=8.dp),shape=RoundedCornerShape(18.dp)){Icon(Icons.Default.Add,null);Text("افزودن شماره")}
    }
}
@Composable private fun EditNumberScreen(id:Long,item:PrivateNumber?,back:()->Unit,save:(String,String)->Unit) {
    var phone by remember(item?.id){mutableStateOf(item?.phoneNumber?:"")};var label by remember(item?.id){mutableStateOf(item?.label?:"")};var error by remember{mutableStateOf<String?>(null)}
    Screen { Header(if(id==0L)"افزودن شماره" else "ویرایش شماره",back)
        Card(Modifier.fillMaxWidth().padding(16.dp),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                Text(if(id==0L)"اطلاعات شماره" else "ویرایش اطلاعات",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                OutlinedTextField(label,{label=it},Modifier.fillMaxWidth(),label={Text("نام یا توضیح (اختیاری)")},singleLine=true,shape=RoundedCornerShape(16.dp))
                OutlinedTextField(phone,{phone=it;error=null},Modifier.fillMaxWidth(),label={Text("شماره تلفن")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone),singleLine=true,shape=RoundedCornerShape(16.dp))
                error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
                Button(onClick={if(phone.isBlank())error="شماره را وارد کنید" else save(phone,label)},Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Text("ذخیره")}
            }
        }
    }
}

@Composable private fun NewEventScreen(vm:VaultViewModel,back:()->Unit) {
    var phone by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var eventType by remember { mutableStateOf("SMS") }
    var direction by remember { mutableStateOf("IN") }
    var error by remember { mutableStateOf<String?>(null) }
    Screen {
        Header("ثبت رویداد محلی",back)
        Text("ثبت دستی برای یادداشت شخصی است؛ این فرم تماس یا پیامکی را رهگیری نمی‌کند.",Modifier.padding(horizontal=16.dp, vertical=8.dp),color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.bodySmall)
        Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(phone,{phone=it;error=null},Modifier.fillMaxWidth(),label={Text("شماره تلفن")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone),singleLine=true,shape=RoundedCornerShape(16.dp))
            Text("نوع رویداد",fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                FilterChip(selected=eventType=="SMS",onClick={eventType="SMS"},label={Text("پیامک")},leadingIcon={Icon(Icons.Default.Sms,null)})
                FilterChip(selected=eventType=="CALL",onClick={eventType="CALL"},label={Text("تماس")},leadingIcon={Icon(Icons.Default.Call,null)})
            }
            Text("جهت",fontWeight=FontWeight.SemiBold)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                FilterChip(selected=direction=="IN",onClick={direction="IN"},label={Text("ورودی")})
                FilterChip(selected=direction=="OUT",onClick={direction="OUT"},label={Text("خروجی")})
            }
            if(eventType=="SMS") OutlinedTextField(body,{body=it},Modifier.fillMaxWidth(),label={Text("متن یادداشت (اختیاری)")},minLines=2,shape=RoundedCornerShape(16.dp))
            error?.let { Text(it,color=MaterialTheme.colorScheme.error) }
            Button(onClick={if(phone.isBlank()) error="شماره را وارد کنید" else vm.addEvent(PrivateEvent(phoneNumber=phone.trim(),eventType=eventType,direction=direction,body=if(eventType=="SMS")body else "")){back()}},Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Text("ثبت رویداد")}
        }
    }
}

@Composable private fun ChatScreen(phone:String,vm:VaultViewModel,back:()->Unit) {
    val all by vm.events.collectAsState(); val thread=all.filter{it.phoneNumber==phone}.sortedBy{it.occurredAt}
    LaunchedEffect(phone,thread.size){vm.markThreadRead(phone)}
    Screen { Header(phone,back)
        Text("جزئیات محلی گفتگو",Modifier.align(Alignment.CenterHorizontally).padding(8.dp),color=MaterialTheme.colorScheme.onSurfaceVariant)
        if(thread.isEmpty()) EmptyCard("رویدادی موجود نیست","این صفحه فقط رویدادهای ذخیره‌شدهٔ محلی را نمایش می‌دهد.")
        LazyColumn(Modifier.weight(1f).fillMaxWidth(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            items(thread,key={it.id}){e->
                val outgoing=e.direction=="OUT"
                Column(Modifier.fillMaxWidth().wrapContentWidth(if(outgoing)Alignment.Start else Alignment.End).background(if(outgoing)Color(0xFFEAE2F6) else Color.White,RoundedCornerShape(18.dp)).padding(14.dp)){
                    Text(if(e.eventType=="CALL")"تماس ${if(outgoing)"خروجی" else "ورودی"}" else e.body.ifBlank{"پیامک ${if(outgoing)"ارسالی" else "دریافتی"}"})
                    Text(formatDate(e.occurredAt),Modifier.padding(top=4.dp),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Text("نمایش سوابق محلی؛ تماس یا پیامک ارسال/رهگیری نمی‌شود.",Modifier.fillMaxWidth().padding(12.dp),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun SettingsScreen(pin:PinViewModel,back:()->Unit,numbers:()->Unit,openPin:()->Unit,navToEvents:()->Unit) {
    val enabled by pin.enabled.collectAsState(); val hasPin by pin.hasPin.collectAsState(); val error by pin.error.collectAsState()
    Screen { Header("تنظیمات",back)
        LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            item{Text("امنیت",color=lilac,fontWeight=FontWeight.Bold)}
            item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(16.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("قفل با PIN",fontWeight=FontWeight.SemiBold);Text("PIN رمزنگاری‌شده با Android Keystore",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(enabled,{pin.setEnabled(it)})}
                TextButton(onClick=openPin){Text(if(hasPin)"تغییر PIN" else "تنظیم PIN")}
                error?.let{Text(it,color=MaterialTheme.colorScheme.error)}
            }}}
            item{Text("داده‌های محلی",color=lilac,fontWeight=FontWeight.Bold)}
            item{SettingCard("شماره‌های خصوصی","افزودن، جستجو، ویرایش و حذف",Icons.Default.Lock,numbers)}
            item{SettingCard("رویدادها","نمایش، جستجو و ثبت دستی رویداد محلی",Icons.Default.History,{ navToEvents() })}
            item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(16.dp)){Text("حریم خصوصی",fontWeight=FontWeight.Bold);Text("این نسخه رهگیری تماس/پیامک، ضبط صدا، ارسال شبکه‌ای یا دورزدن اعلان‌های سیستم ندارد. اتصال به نقش‌های رسمی سیستم عمداً پیاده‌سازی نشده است.",Modifier.padding(top=7.dp),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
        }
    }
}
@Composable private fun SettingCard(title:String,subtitle:String,icon:androidx.compose.ui.graphics.vector.ImageVector,onClick:()->Unit){
    Card(Modifier.fillMaxWidth().clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
        Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=lilac);Column(Modifier.weight(1f).padding(horizontal=12.dp)){Text(title,fontWeight=FontWeight.SemiBold);Text(subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.bodySmall)};Icon(Icons.Default.ChevronLeft,null)}
    }
}

@Composable private fun PinScreen(vm:PinViewModel,setup:Boolean,onSubmit:(String,String?)->Unit) {
    val error by vm.error.collectAsState(); val hasPin by vm.hasPin.collectAsState(); var value by remember{mutableStateOf("")}; var old by remember{mutableStateOf("")}; var confirm by remember{mutableStateOf("")}
    Screen {
        Header(if(setup)"تنظیم PIN" else "ورود امن")
        Column(Modifier.fillMaxSize().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
            Box(Modifier.size(78.dp).background(Color(0xFFEAE2F6),CircleShape),contentAlignment=Alignment.Center){Icon(Icons.Default.Lock,null,tint=lilac,modifier=Modifier.size(36.dp))}
            Text(if(setup)"PIN شش‌رقمی" else "PIN را وارد کنید",Modifier.padding(top=18.dp),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
            Text(if(setup)"برای حفاظت از ورود به فضای خصوصی" else "ورود به حریم پیامک",Modifier.padding(top=6.dp),color=MaterialTheme.colorScheme.onSurfaceVariant)
            if(setup && hasPin) OutlinedTextField(old,{old=it.filter(Char::isDigit).take(6)},Modifier.fillMaxWidth().padding(top=18.dp),label={Text("PIN فعلی")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true,shape=RoundedCornerShape(16.dp))
            OutlinedTextField(value,{value=it.filter(Char::isDigit).take(6)},Modifier.fillMaxWidth().padding(top=18.dp),label={Text(if(setup)"PIN جدید" else "PIN")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true,shape=RoundedCornerShape(16.dp))
            if(setup) OutlinedTextField(confirm,{confirm=it.filter(Char::isDigit).take(6)},Modifier.fillMaxWidth().padding(top=10.dp),label={Text("تکرار PIN جدید")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true,shape=RoundedCornerShape(16.dp))
            error?.let{Text(it,Modifier.padding(top=8.dp),color=MaterialTheme.colorScheme.error)}
            Button(onClick={
                if(setup){ if(value.length != 6) vm.setErrorForUi("PIN باید دقیقاً ۶ رقم باشد") else if(value!=confirm) vm.setErrorForUi("PIN و تکرار آن یکسان نیستند") else onSubmit(value, if(hasPin) old else null) }
                else if(value.length != 6) vm.setErrorForUi("PIN باید دقیقاً ۶ رقم باشد") else onSubmit(value, null)
            },Modifier.fillMaxWidth().padding(top=18.dp),shape=RoundedCornerShape(16.dp)) {Text(if(setup)"ذخیره PIN" else "ورود")}
            if(setup && value.isNotEmpty() && confirm.isNotEmpty() && value!=confirm) Text("PIN و تکرار آن یکسان نیستند",Modifier.padding(top=8.dp),color=MaterialTheme.colorScheme.error)
        }
    }
}
